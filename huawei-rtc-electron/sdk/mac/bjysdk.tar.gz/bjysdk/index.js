/*
 * @Author: Yandong Hu
 * @github: https://github.com/Mad-hu
 * @Date: 2021-08-17 11:11:54
 * @LastEditTime: 2021-09-10 16:31:59
 * @LastEditors: Yandong Hu
 * @Description:
 */
let bjysdk;
if(process.platform == 'win32') {
  bjysdk = require('./platform/win32/sunloginsdk.node');
} else {
  bjysdk = require('./platform/mac/sunloginsdk.node');
}
module.exports = bjysdk;
