declare const deprecate: (replaceApi?: string) => void;
declare class Config {
    glDebug: boolean;
    constructor();
    getGlDebug(): boolean;
    setGlDebug(enable: boolean): void;
    checkWebGL(): boolean;
}
declare enum logLevel {
    none = -1,
    log = 0,
    warn = 1,
    info = 2,
    error = 3
}
declare class hwLog {
    log_level: logLevel;
    constructor(level: logLevel);
    log(level: logLevel, ...optionalParams: any[]): void;
}
declare class hwUtils {
    constructor();
    IsNumber(arg: any): boolean;
    IsBigInt(arg: any): boolean;
    IsString(arg: any): boolean;
    IsObject(arg: any): boolean;
    IsBoolean(arg: any): boolean;
    IsNull(arg: any): boolean;
    calcZoom(vertical?: boolean, contentMode?: number, width?: number, height?: number, clientWidth?: number, clientHeight?: number): number;
}
declare class StringUtil {
    /**
     * 每隔1位用*号替代 比如1234>*2*4
     * @returns 返回脱敏后的数据
     */
    maskEachCommonString(str: string): string;
    /**
     * 2字节全部掩掉，3字节掩掉中间的，4字节以上保留前面2字节和最后一个字节
     * @param val
     */
    getAnonymousId(val: string): any;
}
declare class DomTuil {
    constructor();
    static getChildNodes(parentNode: any, childNodeId: string): any[];
    static removeChildNodes(parentNode: any, childNodeId: string): void;
}
declare const hwutils: hwUtils;
declare const stringUtil: StringUtil;
declare const hwlog: hwLog;
declare const config: Config;
export { config, Config, deprecate, logLevel, hwlog, hwutils, stringUtil, DomTuil };
