/// <reference types="node" />
import SoftwareRenderer from './SoftwareRenderer';
import WebglRenderer from './WebglRenderer';
import RGBRenderer from './RGBRenderer';
import { EventEmitter } from 'events';
export interface IRenderer {
    event: EventEmitter;
    userId: string;
    roomId: string;
    element: any;
    contentMode: number;
    mirror: boolean;
    getRendersuccessstate(): boolean;
    getFirstframestate(): boolean;
    setRendersuccessstate(enable: boolean): void;
    setFirstframestate(enable: boolean): void;
    setMirrorView(enable: boolean): void;
    refreshCanvas(): void;
    setContentMode(mode: number): void;
    drawFrame(imageData: any): void;
    equalsElement(element: Element): boolean;
    bind(element: Element): boolean;
    unbind(): void;
}
export { SoftwareRenderer, WebglRenderer, RGBRenderer };
