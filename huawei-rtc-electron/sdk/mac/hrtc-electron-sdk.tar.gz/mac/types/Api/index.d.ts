/// <reference types="node" />
/**
 * native
 */
import { HWRtcJoinParam, HRTCMultiRoomMediaRelayConfiguration, HRTCLogInfo, HRTCAudioQualityLevel, HRTCAudioSceneType, HRTCRoleType, RendererOptions, HRTCStreamType, HRTCVideoEncParam, HRTCVideoStreamType, RTCVideoMirrorType, HRTCVideoMirrorType, HRTCImageBufferFormat, HRTCDeviceInfo, HRTCNetworkTestConfig, HRTCScreenShareSourceInfos, HRTCScreenShareSourceInfo, HRTCSrceenCaptureOptionalInfo, HRTCRect, HRTCVideoDisplayMode, HRTCVideoAuxiliarEncParam, HRTCVideoEncodeResolutionMode, HRTCTestInfo, HRTCEncryption, HRTCBeautyOptions, HRTCRenderMode, HRTCSize, HRTCScreenShareIconType, HRTCVideoRemoteView, HRTCNetworkBandwidth, HRTCModelType } from './native_type';
import { EventEmitter } from 'events';
import { PluginInfo, Plugin } from './plugin';
/**
 * The HRTCEngine class.
 */
declare class HRTCEngine extends EventEmitter {
    private rtcEngine;
    private streams;
    private myselfInfo;
    private rtcMediaType;
    private renderMode;
    private localVideoRender;
    private remoteVideoRender;
    private localDataRender;
    private remoteDataRender;
    private testInfo;
    private dumpFileEnable;
    webglCount: number;
    currentScreenUid: string;
    constructor();
    /**
     * Decide whether to use software/webgl/RGBA rendering.
     * @param {0|3} mode:
     * - 0 for software rendering.
     * - 1 for webgl rendering
     * - 3 for RGBA rendering.
     */
    setRenderMode(mode: HRTCRenderMode): void;
    setupLocalView(view: Element, displayMode?: HRTCVideoDisplayMode): number;
    setupLocalVideoView(view: Element, options?: RendererOptions): number;
    setupRemoteVideoView(userId: string, view: Element, options?: RendererOptions): number;
    setupRemoteAuxiliaryView(userId: string, view: Element, options?: RendererOptions): number;
    /**
     *
     * @param userId
     * @param mode
     * @param isAux
     * @param roomId
     * @returns
     */
    setViewDisplayMode(userId: string, mode: HRTCVideoDisplayMode, isAux?: boolean | undefined): number;
    setLocalViewMirror(enable: RTCVideoMirrorType): number;
    updateLocalRenderMode(displayMode: HRTCVideoDisplayMode, mirrorMode: HRTCVideoMirrorType): number;
    updateViewMirrorMode(userId: string, mirror: boolean): number;
    /**
     *
     * @param key
     * @param roomId
     */
    resizeRender(key: 'local' | string, roomId: string | undefined): void;
    /**
     * Destroys the renderer.
     * @param key Key for the map that store the renderers,
     * e.g, `uid` or `local`.
     * @param onFailure The error callback for the {@link destroyRenderer}
     * method.
     */
    destroyRender(key: 'local' | string, roomId: string | undefined, onFailure?: (err: Error) => void): void;
    /**
     * 设置远端视图渲染模式,镜像模式
     * @param userId
     * @param displayMode
     * @param mirrorMode
     */
    updateRemoteRenderMode(userId: string, displayMode: HRTCVideoDisplayMode, mirrorMode: HRTCVideoMirrorType): number;
    /**
     * 设置远端用户视频的mirror模式
     * @param userId
     * @param enable
     */
    setRemoteViewMirrorMode(userId: string, enable: boolean): number;
    /**
     * 设置远端用户共享流的mirror模式
     * @param userId
     * @param enable
     */
    setRemoteAuxiliaryStreamViewMirrorMode(userId: string, enable: boolean): number;
    /**
     *
     * @param options
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    initialize(appId: string, countryCode: string, enableHaTrace: boolean, logInfo: HRTCLogInfo): number;
    /**
     *
     * @param options
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    testConfiguration(testInfo: HRTCTestInfo): number;
    /**
     *
     * @param level
     * @param scene
     */
    setAudioConfig(level: HRTCAudioQualityLevel, scene: HRTCAudioSceneType): number;
    /**
     * @param remoteUserId
     * @param data
     * @param length
     */
    sendCommandData(remoteUserId: string, data: string, length: number): number;
    /**
     * @param interval
     */
    recordingDeviceTest(interval: number): number;
    /**
     *
     */
    finishRecordingDeviceTest(): number;
    /**
     *
     * @param filePath
     */
    playbackDeviceTest(filePath: string): number;
    /**
     *
     */
    finishPlaybackDeviceTest(): number;
    /**
     *
     */
    echoTest(interval: number): number;
    /**
     *
     */
    finishEchoTest(): number;
    /**
     *
     */
    cameraDeviceTest(): number;
    /**
     *
     */
    finishCameraDeviceTest(): number;
    /**
     *
     * @param myself
     */
    isPlayMixMyself(myself: boolean): number;
    /**
     *
     * @param withMic
     */
    isMixWithMicrophone(withMic: boolean): number;
    logUpload(): number;
    /**
     *
     * @param newSig
     * @param ctime
     */
    renewAuthorization(newSig: string, ctime: number): number;
    /**
     *
     * @param config
     */
    setParameters(config: string): number;
    /**
     * Returns the version and the build information of the current SDK.
     * @return The version of the current SDK.
     */
    getVersion(): string;
    /**
     *
     * @param taskId
     * @param initTranscodeConfig
     * - 0: Success.
     * - < 0: Failure.
     */
    startPublishStream(taskId: string, setRTMPurls: [string], initTranscodeConfig: any): number;
    /**
     *
     * @param taskId
     * @param initTranscodeConfig
     * - 0: Success.
     * - < 0: Failure.
     */
    updateTransCoding(taskId: string, initTranscodeConfig: any): number;
    /**
     *
     * @param taskId
     * - 0: Success.
     * - < 0: Failure.
     */
    stopPublishStream(taskId: string): number;
    /**
     *
     * @param hrtcEncryption
     * - 0: Success.
     * - < 0: Failure.
     */
    setEncryption(hrtcEncryption: HRTCEncryption): number;
    /**
     *
     * @param hrtcEncryption
     * - 0: Success.
     * - < 0: Failure.
     */
    setEncDecryptFrameObserver(pluginPath: string): number;
    /**
     * @param HWRtcJoinParam
     * - 0: Success.
     * - < 0: Failure.
     */
    joinRoom(hWRtcJoinParam: HWRtcJoinParam): number;
    /**
     * @param HRTCMultiRoomMediaRelayConfiguration
     * 新增远端跨房
     * - 0: Success.
     * - < 0: Failure.
     */
    addMultiRoomMediaRelay(roomMediaRelayConfiguration: HRTCMultiRoomMediaRelayConfiguration): any;
    /**
     * @param HRTCMultiRoomMediaRelayConfiguration
     * 退出远端跨房
     * - 0: Success.
     * - < 0: Failure.
     */
    removeMultiRoomMediaRelay(roomMediaRelayConfiguration: HRTCMultiRoomMediaRelayConfiguration): any;
    /**
     * 停止所有跨房
     * - 0: Success.
     * - < 0: Failure.
     */
    stopMultiRoomMediaRelay(): number;
    /**
     * @param HWRtcJoinParam
     * - 0: Success.
     * - < 0: Failure.
     */
    sendAudioSeiMsg(msg: string, count: number): number;
    /**
     *
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    leaveRoom(): number;
    /**
     * 是否RTCEngine实例，调用此方法后所有接口都无法再调用
     * 如果要重新适应RtcEngine 必须调用 initialize 接口
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    release(): number;
    /**
     * 关闭SDK抓取dmp的能力，只能在 initialized 接口前调用才能生效
     */
    disableCrashDumpFile(): number;
    changeUserRole(roletype: HRTCRoleType, authorization: string, ctime: number): number;
    /**
     *
     * @param localenable
     * @param remoteenable
     */
    setExternalVideoFrameOutput(localEnable: boolean, remoteEnable: boolean, frameFormat?: HRTCImageBufferFormat): number;
    setVideoRenderFPS(fps: number): number;
    /**
     * Video Preview
     */
    startLocalPreview(): number;
    /**
     *
     */
    stopLocalPreview(): number;
    /**
     * 订阅
     * @param userId
     * @param view
     * @param disableAdjustRes
     */
    startRemoteVideoStream(userId: string, streamType: HRTCStreamType, disableAdjustRes: boolean): number;
    startRemoteStreamView(userId: string, view: Element, streamType: HRTCStreamType, disableAdjustRes: boolean): number;
    startAllRemoteView(counts: number, viewInfo: HRTCVideoRemoteView[]): any;
    /**
     * 取消订阅
     * @param userId
     */
    stopRemoteStreamView(userId: string): number;
    /**
     * @param enable
     * @param timeInterval
     * @returns
     */
    enableStreamRecvPacketNotify(enable: boolean, timeInterval: number): number;
    /**
     *
     * @param mirrorType 必选，RTCVideoMirrorType类型。
     * @returns
     */
    setVideoEncoderMirror(mirrorType: HRTCVideoMirrorType): number;
    /**
     *
     * @param userId 必选，string类型，用户ID。
     * @param type 必选，HRTCVideoStreamType类型，0为大流，1为小流
     * @returns
     */
    setRemoteVideoStreamType(userId: string, type: HRTCVideoStreamType): number;
    /**
     *
     * @param type
     * @returns
     */
    setPriorRemoteVideoStreamType(type: HRTCVideoStreamType): number;
    /**
     *
     * @param enable
     * @returns
     */
    enableHowlingDetect(enable: boolean): number;
    /**
     *
     * @param encoderparam 设置视频流（默认流或者大流）的编码参数。
     * @returns
     */
    setVideoEncoderConfig(encoderparam: HRTCVideoEncParam): number;
    /**
     *
     * @param enable 设置是否开启远端流分辨率自适应。默认开启
     */
    setRemoteVideoAdjustResolution(enable: boolean): number;
    /**
     * 设置是否开启打点统计。开启打点统计，在initialize前调用
     * @param enable
     */
    enableStats(enable: boolean): number;
    /**
     * 是否激活视频流大小流功能，并设置小流的编码参数。
     * @param enable
     * @param smallVideoParam
     * @returns
     */
    enableSmallVideoStream(enable: boolean, smallVideoParam?: HRTCVideoEncParam): number;
    initializePluginManager(): number;
    unregisterPlugin(pluginId: string): number;
    releasePluginManager(): number;
    getPlugins(): any;
    registerPlugin(info: PluginInfo): number;
    /**
     * @param pluginId
     * @param enabled
     */
    enablePlugin(pluginId: string, enabled: boolean): number;
    createPlugin(pluginId: string): Plugin;
    /**
     * @param pluginId
     * @param param
     */
    setPluginParameter(pluginId: string, param: string): number;
    /**
     * @param pluginId
     * @param paramKey
     */
    getPluginParameter(pluginId: string, paramKey: string): string;
    /**
     * 音视频设备管理
     */
    setAudioRecordDevice(deviceId: string): number;
    /**
     *
     * @returns
     */
    getAudioRecordDevices(): Array<HRTCDeviceInfo>;
    /**
     *
     * @returns
     */
    getCurrentAudioRecordDevice(): string;
    /**
     * mute：必选，boolean类型，音频采集设备是否静音，true表示静音，false表示取消静音。
     * @param mute
     */
    setAudioRecordDeviceMute(mute: boolean): number;
    /**
     * 获取音频采集设备静音状态。
     * @returns
     */
    getAudioRecordDeviceMute(): boolean;
    /**
     *
     * @param volume
     * @returns
     */
    setAudioRecordVolume(volume: number): number;
    /**
     * 获取当前音频采集设备音量
     * @returns
     */
    getAudioRecordVolume(): number;
    /**
     *
     * @param deviceId
     * @returns
     */
    setAudioPlaybackDevice(deviceId: string): number;
    /**
     *
     * @returns
     */
    getAudioPlaybackDevices(): Array<HRTCDeviceInfo>;
    /**
     *
     */
    getCurrentAudioPlaybackDevice(): string;
    /**
     * 设置音频播放设备静音。
     * @param mute
     */
    setAudioPlaybackDeviceMute(mute: boolean): number;
    /**
     * 获取音频播放设备静音状态。
     * @returns
     */
    getAudioPlaybackDeviceMute(): boolean;
    /**
     * 设置音频播放音量。
     * @param volume  volume：必选，number类型，设置音频播放的音量，取值范围为[0,100]
     * @returns
     */
    setAudioPlaybackVolume(volume: number): number;
    enableCommandMsg(enable: boolean): number;
    /**
     *
     * @returns
     */
    getAudioPlaybackVolume(): number;
    /**
     *
     * @param deviceId
     * @returns
     */
    setVideoDevice(deviceId: string): number;
    /**
     * 获取视频采集设备列表
     * @returns
     */
    getVideoDevices(): Array<HRTCDeviceInfo>;
    /**
     * 获取视频采集设备列表
     * @returns
     */
    getCurrentVideoDevice(): string;
    /**
     * 开启/关闭本地视频采集。
     * @param enable
     * @returns
     */
    enableLocalVideo(enable: boolean): number;
    /**
     * 停止/恢复发送本地视频流
     * @param mute
     * @returns
     */
    muteLocalVideoStream(mute: boolean): number;
    /**
     * 停止/恢复接收指定的远端视频流。
     * @param userId
     * @param mute
     * @returns
     */
    muteRemoteVideoStream(userId: string, mute: boolean): number;
    /**
     * 停止/恢复接收全部远端视频流
     * @param mute
     * @returns number类型，0表示调用成功，其它值表示调用失败
     */
    muteAllRemoteVideoStreams(mute: boolean): number;
    /**
     * 停止/恢复发送本地音频流。
     * @param mute
     * @returns
     */
    muteLocalAudioStream(mute: boolean): number;
    /**
     * 停止/恢复接收指定的远端音频流。
     * @param userId
     * @param mute
     * @returns
     */
    muteRemoteAudioStream(userId: string, mute: boolean): number;
    /**
     * 停止/恢复接收全部远端音频流。
     * @param mute
     * @returns
     */
    muteAllRemoteAudioStreams(mute: boolean): number;
    /**
     * 开启/关闭本地音频采集。
     * @param enable
     * @returns
     */
    enableLocalAudioStream(enable: boolean): number;
    /**
     * 设置远端用户音量上报周期。
     * @param interval
     * @returns
     */
    enableUserVolumeNotify(interval: number): number;
    /**
     * 调节音频采集音量。
     * @param volume
     * @returns
     */
    adjustRecordingVolume(volume: number): number;
    /**
     * 调节音频播放音量。
     * @param volume
     * @returns
     */
    adjustPlaybackVolume(volume: number, userId?: string): number;
    /**
     * 设置是否开启系统音频采集、发送，只能在房间内使用
     * @param enable
     * @returns
     */
    setShareComputerSound(enable: boolean): number;
    /**
     * 开启音频自渲染
     * @param localEnable
     * @param remoteEnable
     * @returns
     */
    setExternalAudioFrameOutput(localEnable: boolean, remoteEnable: boolean): number;
    /**
     * 开始播放音频文件，房间内调用。远端用户订阅本端音频流后可以听到此音频
     * @param filePath 音频文件的本地全路径
     * @param playMode 播放模式
     * @param cycle 循环次数，0表示无限循环
     * @param replace 远端模式下面是否需要和麦克风做混音
     */
    startAudioFile(filePath: string, playMode: number, cycle: number, replace: number, startPos?: number): number;
    /**
     * 停止播放音频文件，房间内调用，若角色为“publisher”，不支持调用
     */
    stopAudioFile(): number;
    /**
     * 暂停播放音频文件，房间内调用
     */
    pauseAudioFile(): number;
    /**
     * 恢复播放音频文件，房间内调用
     */
    resumeAudioFile(): number;
    /**
     * 调节音乐文件播放音量
     * @param volume
     */
    adjustAudioFileVolume(volume: number): number;
    /**
     * 获取音乐文件播放音量
     */
    getAudioFileVolume(): number;
    /**
     * 获取音乐文件播放时长
     */
    getAudioFileDuration(): number;
    /**
     * 获取音乐文件播放当前播放进度
     * @returns
     */
    getAudioFilePosition(): number;
    /**
     * 设置音乐文件播放进度
     * @param position
     */
    setAudioFilePosition(position: number): number;
    /**
     * 调节音乐文件的本地播放音量
     * @param volume
     * @returns
     */
    adjustAudioFilePlayoutVolume(volume: number): number;
    /**
     * 调节音乐文件的远端播放音量
     * @param volume
     * @returns
     */
    adjustAudioFilePublishVolume(volume: number): number;
    /**
     * 获取音乐文件的本地播放音量
     * @returns
     */
    getAudioFilePlayoutVolume(): number;
    /**
     * 获取音乐文件的远端播放音量
     * @returns
     */
    getAudioFilePublishVolume(): number;
    /**
     * 获取音效文件的播放音量
     * @returns
     */
    getAudioClipsVolume(): number;
    /**
     * 设置音效文件的播放音量
     * @param volume
     * @returns
     */
    setAudioClipsVolume(volume: number): number;
    /**
     * 获取指定音效文件的播放音量
     * @param sounderId sounderId：指定音效Id
     * @returns
     */
    getVolumeOfAudioClip(sounderId: number): number;
    /**
     * 实时调整音效文件的播放音量
     * @param soundId  soundId：指定音效Id
     * @param volume   volume: 播放音量
     * @returns
     */
    setVolumeOfAudioClip(soundId: number, volume: number): number;
    /**
     * 播放指定音效文件
     * @param soundId 指定音效Id
     * @param filepath 文件路径
     * @param loop 循环播放次数
     * @param pitch 音效的音调，取值范围为 [0.5,2.0]。默认值为 1.0，表示原始音调。取值越小，则音调越低
     * @param pan 音效的空间位置。取值范围为 [-1.0,1.0]
     * @param gain 音效的音量
     * @param publish 是否推送
     * @param startPos 播放起始位置
     * @returns
     */
    playAudioClip(soundId: number, filepath: string, loop: number, pitch: number, pan: number, gain: number, publish: number, startPos: number): number;
    /** */
    stopAudioClip(soundId: number): number;
    /**
     * 停止播放所有音效文件
     * @returns
     */
    stopAllAudioClips(): number;
    /**
     * 将音效文件加载至内存
     * @param soundId 指定音效Id
     * @param filePath 文件路径
     * @returns
     */
    preloadAudioClip(soundId: number, filePath: string): number;
    /**
     *
     * @param soundId
     * @returns
     */
    unloadAudioClip(soundId: number): number;
    /**
     * 暂停音效文件播放
     * @param soundId
     * @returns
     */
    pauseAudioClip(soundId: number): number;
    /**
     * 暂停所有音效文件播放
     * @returns
     */
    pauseAllAudioClips(): number;
    /**
     * 恢复播放指定音效文件
     * @param soundId
     * @returns
     */
    resumeAudioClip(soundId: number): number;
    resumeAllAudioClips(): number;
    getAudioClipCurrentPosition(soundId: number): number;
    setAudioClipPosition(soundId: number, position: number): number;
    getAudioClipDuration(filePath: string): number;
    startNetworkTest(config: HRTCNetworkTestConfig): number;
    stopNetworkTest(): number;
    /**
     * @param HRTCNetworkBandwidth
     */
    setNetworkBandwidth(bandwidthParam: HRTCNetworkBandwidth): number;
    /**
     *
     * @param thumbnailSize 缩略图大小
     * @returns
     */
    getScreenShareSources(type: HRTCScreenShareIconType): HRTCScreenShareSourceInfos;
    /**
     *
     * @param thumbnailSize 缩略图大小
     * @returns
     */
    getScreenShareSourceInfos(thumbnailSize: HRTCSize): HRTCScreenShareSourceInfos;
    /**
     *
     * @param info
     * @param optionalInfo
     * @returns
     */
    setScreenShareTarget(info: HRTCScreenShareSourceInfo, optionalInfo: HRTCSrceenCaptureOptionalInfo): number;
    updateScreenShareRegion(rect: HRTCRect): number;
    /**
     * 方法调用成功
     * @returns
     */
    startScreenShare(): number;
    /**
     * 停止屏幕共享
     * @returns
     */
    stopScreenShare(): number;
    startRemoteAuxiliaryStream(userId: string): number;
    startRemoteAuxiliaryStreamView(userId: string, view: Element): number;
    stopRemoteAuxiliaryStreamView(userId: string): number;
    setAuxiliaryVideoEncodeSmooth(enable: boolean): number;
    updateRemoteAuxiliaryStreamRenderMode(userId: string, displayMode: HRTCVideoDisplayMode, mirrorMode: HRTCVideoMirrorType): number;
    addHiddenShareWindow(view: number): number;
    deleteHiddenShareWindow(view: number): number;
    removeAllHiddenShareWindow(): number;
    setAuxiliaryVideoEncoderConfig(encoderParams: HRTCVideoAuxiliarEncParam): number;
    setVideoEncodeResolutionMode(resolutionMode: HRTCVideoEncodeResolutionMode): number;
    setAuxiliaryExternalVideoFrameOutput(localEnable: boolean, remoteEnable: boolean): number;
    setBeautyRetouchOption(isBeautyRetouch: boolean, beautyParam: HRTCBeautyOptions): number;
    setBackgroundBlur(enable: boolean, radius: number): number;
    setBackgroundReplace(enable: boolean, imagePath: string): number;
    setAccessResourceType(resType: number): number;
    loadModel(modelType: HRTCModelType, modelPath: string): number;
    unloadModel(modelType: HRTCModelType): number;
    /**
    * 使能使能VAD人声检测和啸叫抑制
    * @param enable
    */
    enableModel(modelType: HRTCModelType, enable: boolean): number;
    /**
     * 使能音频降噪功能
     * @param enable
     */
    enableAudioTNR(enable: boolean): number;
    /**
     * sdk 内部私有方法
     */
    private _getConfigObject;
    private _isRemote;
    /**
     * 获取渲染器列表
     * @param type
     * @param uid
     * @param roomId
     */
    private __getRenderers;
    private _getRoomRenderers;
    /**
     * 检查数据是否正确
     * @private
  
     * @param {*} vdata
     * @param {*} udata
     * @param {*} ydata
     * @param {*} header
     */
    private _checkData;
    private _sendRenderNotify;
    private _checkVideoFirstFrame;
    private _checkVideoRenderSuccess;
    private _deliverRGBAData;
    private _deliverYUVData;
    /**
     * register renderer for target info
     * @private
  
     * @param {number} infos
     */
    private _onRegisterDeliverFrame;
    /**
     * 判断是否要对外回调 辅流数据
     * @param info
     */
    private _isRenderDataOutPut;
    /**
     * 判断是否要对外回调 视频流数据
     * @param info
     */
    private _isVideoDataOutPut;
    private _getMediaType;
    /**
     * Initializes the renderer.
     * @param key Key for the map that store the renderers,
     * e.g, uid or  `local`.
     * @param view The Dom elements to render the video.
     */
    private _initRender;
    /**
     * 将旧的渲染器根据渲染模式创建新的渲染器
     * @param oldRender
     * @param renderMode
     */
    private _reInitRender;
    private _getRenderers;
    private _getRendererByView;
    private _getAllRenders;
    private _removeRender;
    private _destroyRenderView;
    private _setRenderMirrorMode;
    private _initEngine;
    private _initData;
    private _invokingEngine;
    /**
     * init event handler
     * @private
     */
    private _initEventHandler;
}
export default HRTCEngine;
