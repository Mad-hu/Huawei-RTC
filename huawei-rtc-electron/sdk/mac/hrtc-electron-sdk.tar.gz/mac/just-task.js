/**
 * 当从npm 仓库安装时 触发该脚本，同步lib库
 */
 const { task, option, argv } = require('just-task');
 const fs = require('fs-extra');
 const path = require('path');
 
 option('platform', { default: process.platform, choices: ['darwin', 'win32', 'linux'] });
 const packageObject = require('./package.json');
 var child = require('child_process');
 
 task('install-local-mac', async () => {
   const platform = argv().platform;
   const version = packageObject.version;
   console.log(`just install start platform=${platform} version=${version}`, platform);
 
   // 获取Release路径
   const libReleasePath = path.join(__dirname, 'build', 'Release');
  
   // 手动创建软连接
   console.log('create soft link start')
   createFrameWorkSoftLink(libReleasePath)

 });

 function createFrameWorkSoftLink(libReleasePath){
  const libHRTCEngineFrameworkPath = path.join(libReleasePath, 'libHRTCEngine.framework');
   // 创建 Headers的软连接
   createFrameWorkOneSoftLink(libHRTCEngineFrameworkPath,'Headers')
   createFrameWorkOneSoftLink(libHRTCEngineFrameworkPath,'Modules')
   createFrameWorkOneSoftLink(libHRTCEngineFrameworkPath,'Resources')
  //创建  libHRTCEngine软连接
  createFrameWorkOneSoftLink(libHRTCEngineFrameworkPath,'libHRTCEngine','File')
  // 创建 Current的软连接
  createFrameWorkCurrentFolderLink(libHRTCEngineFrameworkPath)
  // hwffmpeg 软连接
  const hwffmpegFrameworkPath = path.join(libReleasePath, 'hwffmpeg.framework');
  createFrameWorkOneSoftLink(hwffmpegFrameworkPath,'Resources')
  createFrameWorkOneSoftLink(hwffmpegFrameworkPath,'hwffmpeg','File')
  createFrameWorkCurrentFolderLink(hwffmpegFrameworkPath)
 
 }

 function createFrameWorkOneSoftLink(frameworkPath, name,type='Folder'){
  console.log(`createFrameWorkFolerLink frameworkPath=${frameworkPath} name=${name} type=${type}`)
  const dest=path.join(frameworkPath, name)
  const source=path.join(frameworkPath, 'Versions','A',name)
  console.log(`dest=${dest} source=${source}`)
  let removeDestRes
  if(type==='File'){
     removeDestRes = child.execSync(`rm -f ${dest}`, { encoding: 'utf8' });
  }else{
     removeDestRes = child.execSync(`rm -rf ${dest}`, { encoding: 'utf8' });
  }
  console.log(`removeDestRes=${removeDestRes}`)
  const createSoftLinkRes = child.execSync(`ln -s ${source} ${dest} `, { encoding: 'utf8' });
  console.log(`createSoftLinkRes=${createSoftLinkRes}`)
 }

 function createFrameWorkCurrentFolderLink(frameworkPath){
  console.log(`createFrameWorkCurrentFolderLink frameworkPath=${frameworkPath}`)
  const dest=path.join(frameworkPath, 'Versions','Current')
  const source=path.join(frameworkPath, 'Versions','A')
  console.log(`dest=${dest} source=${source}`)
  let removeDestRes
  removeDestRes = child.execSync(`rm -rf ${dest}`, { encoding: 'utf8' });
  console.log(`removeDestRes=${removeDestRes}`)
  const createSoftLinkRes = child.execSync(`ln -s ${source} ${dest} `, { encoding: 'utf8' });
  console.log(`createSoftLinkRes=${createSoftLinkRes}`)
 }


 