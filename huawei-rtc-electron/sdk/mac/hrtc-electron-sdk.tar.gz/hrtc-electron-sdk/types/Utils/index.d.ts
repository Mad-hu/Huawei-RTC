declare const deprecate: (replaceApi?: string) => void;
declare class Config {
    glDebug: boolean;
    constructor();
    getGlDebug(): boolean;
    setGlDebug(enable: boolean): void;
    checkWebGL(): boolean;
}
declare enum logLevel {
    none = -1,
    log = 0,
    warn = 1,
    info = 2,
    error = 3
}
declare class hwLog {
    log_level: logLevel;
    constructor(level: logLevel);
    log(level: logLevel, ...optionalParams: any[]): void;
}
declare class hwUtils {
    constructor();
    IsNumber(arg: any): boolean;
    IsBigInt(arg: any): boolean;
    IsString(arg: any): boolean;
    IsObject(arg: any): boolean;
    IsBoolean(arg: any): boolean;
    IsNull(arg: any): boolean;
    calcZoom(vertical?: boolean, contentMode?: number, width?: number, height?: number, clientWidth?: number, clientHeight?: number): number;
}
declare const hwutils: hwUtils;
declare const hwlog: hwLog;
declare const config: Config;
export { config, Config, deprecate, logLevel, hwlog, hwutils };
