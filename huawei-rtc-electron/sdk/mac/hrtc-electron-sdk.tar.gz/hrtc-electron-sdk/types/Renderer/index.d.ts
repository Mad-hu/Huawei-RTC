/// <reference types="node" />
import SoftwareRenderer from './SoftwareRenderer';
import RGBRenderer from './RGBRenderer';
import { EventEmitter } from 'events';
export interface IRenderer {
    event: EventEmitter;
    getRendersuccessstate(): boolean;
    getFirstframestate(): boolean;
    setRendersuccessstate(enable: boolean): void;
    setFirstframestate(enable: boolean): void;
    setMirrorView(enable: boolean): void;
    refreshCanvas(): void;
    setContentMode(mode: number): void;
    drawFrame(imageData: any): void;
    equalsElement(element: Element): boolean;
    bind(element: Element): void;
    unbind(): void;
    getRenderMode(): number;
    getELement(): any;
}
export { SoftwareRenderer, RGBRenderer };
