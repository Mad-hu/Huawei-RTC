/// <reference types="node" />
/**
 * native
 */
import { NodeRtcEngine, Joinroom_UserInfo, logInfoParam, HRTCConnStateTypes, HRTCConnChangeReason, HRTCLeaveReason, HRTCStatsInfo, HRTCRoleType, HRTCDisplayMode, RendererOptions, HRTCStreamType, HRTCVideoEncParam, HRTCVideoStreamType, Joinroom_SelfInfo, Joinroom_MediaType, RTCVideoMirrorType, HRTCVideoMirrorType, HRTCRemoteAudioStreamState, HRTCRemoteMicState, HRTCRemoteAudioStreamStateReason, HRTCRemoteVideoStreamState, HRTCRemoteVideoStreamStateReason, HRTCLocalVideoStats, HRTCRemoteVideoStats, HRTCLocalAudioStats, HRTCRemoteAudioStats, NodeRenderType, HRTCImageBufferFormat, HRTCDeviceInfo, HRTCRemoteAudioMode, HRTCLocalVideoStreamState, HRTCLocalVideoStreamStateReason, HRTCLocalAudioStreamState, HRTCLocalAudioStreamStateReason, HRTCDeviceType, HRTCDeviceState, HRTCVolumeInfo, HRtcStatsInfo_All, HRTCAudioFileState, HRTCAudioFileReason, HRTCNetworkQualityLevel, HRTCNetworkTestResult, HRTCQualityInfo, HRTCNetworkTestConfig, HRTCMediaOptions, HRTCScreenCaptureIconType, HRTCScreenCaptureSourceInfos, HRTCScreenCaptureSourceInfo, HRTCSrceenCaptureOptionalInfo, HRTCVideoDisplayMode, HRTCSubStreamEncParam, HRTCVideoEncodeResolutionMode } from './native_type';
/**
 * renderer
 */
import { IRenderer } from '../Renderer';
import { EventEmitter } from 'events';
import { Config } from '../Utils';
import { PluginInfo, Plugin } from './plugin';
/**
 * The HRTCEngine class.
 */
declare class HRTCEngine extends EventEmitter {
    rtcEngine: NodeRtcEngine;
    streams: Map<string, Map<string, IRenderer[]>>;
    pauseRender: boolean;
    myselfInfo: Map<string, Joinroom_SelfInfo>;
    rtcMediaType: Joinroom_MediaType;
    renderMode: 0 | 3 | number;
    localVideoRender: boolean;
    remoteVideoRender: boolean;
    localDataRender: boolean;
    remoteDataRender: boolean;
    currentScreenUid: string;
    constructor();
    setPauseRenderer(pause?: boolean): void;
    /**
     * return sdk config object
     */
    getConfigObject(): Config;
    getSelfId(roomId: string): string;
    /**
     * Decide whether to use software/RGBA rendering.
     * @param {0|3} mode:
     * - 0 for software rendering.
     * - 3 for RGBA rendering.
     */
    setRenderMode(mode?: 0 | 3 | number): void;
    /**
     * @private
     * @ignore
     * @param {number} type 1-remote 0-local
     * @param {string} differ from electron engine's uid, uid get from native engine
     */
    _getRenderers(type: number, uid: string, roomId: string | undefined): IRenderer[] | undefined;
    _getRoomRenderers(roomId: string): Map<string, IRenderer[]>;
    /**
     * check if data is valid
     * @private
     * @ignore
     * @param {*} vdata
     * @param {*} udata
     * @param {*} ydata
     * @param {*} header
     */ _checkData(header: ArrayBuffer, ydata: ArrayBuffer, udata: ArrayBuffer, vdata: ArrayBuffer): boolean;
    sendRenderNotify(event: string, ...args: Array<any>): void;
    checkVideoFirstFrame(renderer: IRenderer, type: NodeRenderType, roomId?: string, uid?: string, width?: number, height?: number): void;
    checkVideoRenderSuccess(renderer: IRenderer, type: NodeRenderType, roomId?: string, uid?: string): void;
    deliverRGBAData(info: any): boolean;
    deliverYUVData(info: any): boolean;
    /**
     * register renderer for target info
     * @private
     * @ignore
     * @param {number} infos
     */
    onRegisterDeliverFrame(info: any): void;
    /**
     *
     * @param key
     * @param roomId
     */
    resizeRender(key: 'local' | string, roomId: string | undefined): void;
    getMediaType(userId: string): string;
    /**
     * Initializes the renderer.
     * @param key Key for the map that store the renderers,
     * e.g, uid or  `local`.
     * @param view The Dom elements to render the video.
     */
    initRender(key: 'local' | string, view: Element, roomId: string | undefined, displayMode?: HRTCDisplayMode, options?: RendererOptions): void;
    destroyRenderView(key: 'local' | string, roomId: string | undefined, view: Element, onFailure?: (err: Error) => void): void;
    /**
     * Destroys the renderer.
     * @param key Key for the map that store the renderers,
     * e.g, `uid` or `local`.
     * @param onFailure The error callback for the {@link destroyRenderer}
     * method.
     */
    destroyRender(key: 'local' | string, roomId: string | undefined, onFailure?: (err: Error) => void): void;
    setRenderMirrorMode(roomId: string, userId: string, enable: boolean): number;
    /**
     * init event handler
     * @private
     * @ignore
     */
    initEventHandler(): void;
    /**
     *
     * @param enable
     * @param logInfo
     * @returns
     * * - 0: Success.
     * - < 0: Failure.
     */
    setLogParam(enable: boolean, logInfo: logInfoParam): number;
    logUpload(): number;
    /**
     *
     * @param newSig
     * @param ctime
     */
    renewSignature(newSig: string, ctime: number): number;
    /**
     *
     * @param config
     */
    setParameters(config: string): number;
    /**
     *
     * @param options
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    initialize(appId: string, domain?: string): number;
    /**
     * Returns the version and the build information of the current SDK.
     * @return The version of the current SDK.
     */
    getVersion(): string;
    /**
     *
     * @param userinfo
     * @param roominfo
     * - 0: Success.
     * - < 0: Failure.
     */
    joinRoom(roomId: string, userinfo: Joinroom_UserInfo, option: HRTCMediaOptions): number;
    /**
     *
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    leaveRoom(): number;
    /**
     * Releases the HRTCEngine instance.
     *
     * Once the App calls this method to release the created HRTCEngine
     * instance, no other methods in the SDK
     * can be used and no callbacks can occur. To start it again, initialize
     * {@link initialize} to establish a new
     * HRTCEngine instance.
     *
     * **Note**: Call this method in the subthread.
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    release(): number;
    setUserRole(roletype: HRTCRoleType): number;
    /**
     * Specifies an SDK output log file.
     *
     * The log file records all log data for the SDK’s operation. Ensure that
     * the directory for the log file exists and is writable.
     *
     * @param {string} filepath File path of the log file. The string of the
     * log file is in UTF-8.
     * @return
     * - 0: Success.
     * - < 0: Failure.
     */
    setAddonLogFile(filepath: string): number;
    /**
     *
     * @param localenable
     * @param remoteenable
     */
    setExternalVideoFrameOutput(localEnable: boolean, remoteEnable: boolean, frameFormat?: HRTCImageBufferFormat): number;
    /**
     * Video Preview
     */
    startPreview(): number;
    /**
     *
     */
    stopPreview(): number;
    /**
     *
     * @param view
     * @param displayMode
     */
    setupLocalView(view: Element, displayMode?: HRTCDisplayMode): number;
    setVideoRenderFPS(fps: number): number;
    /**
     * 暂时不封装
     * @param userId
     * @param view
     * @param roomId
     * @param options
     */
    /**
     * 订阅
     * @param userId
     * @param view
     * @param disableAdjustRes
     */
    startRemoteStreamView(userId: string, view: Element, streamType: HRTCStreamType, disableAdjustRes: boolean): number;
    /**
     * 取消订阅
     * @param userId
     */
    stopRemoteStreamView(userId: string): number;
    /**
     *
     * @param userId
     * @param mode
     * @param isAux
     * @param roomId
     * @returns
     */
    setViewDisplayMode(userId: string, mode: HRTCDisplayMode, isAux?: boolean | undefined): number;
    setLocalViewMirror(enable: RTCVideoMirrorType): number;
    /**
     *
     * @param userId
     * @param enable
     * @returns
     */
    setRemoteViewMirrorMode(userId: string, enable: boolean): number;
    /**
     *
     * @param mirrorType 必选，RTCVideoMirrorType类型。
     * @returns
     */
    setVideoEncoderMirror(mirrorType: HRTCVideoMirrorType): number;
    /**
     *
     * @param userId 必选，string类型，用户ID。
     * @param type 必选，HRTCVideoStreamType类型，0为大流，1为小流
     * @returns
     */
    setRemoteVideoStreamType(userId: string, type: HRTCVideoStreamType): number;
    /**
     *
     * @param type
     * @returns
     */
    setPriorRemoteVideoStreamType(type: HRTCVideoStreamType): number;
    /**
     *
     * @param enable
     * @param timeInterval
     * @returns
     */
    enableStreamRecvPacketNotify(enable: boolean, timeInterval: number): number;
    /**
     *
     * @param enable
     * @returns
     */
    enableHowlingDetect(enable: boolean): number;
    /**
     *
     * @param encoderparam 设置视频流（默认流或者大流）的编码参数。
     * @returns
     */
    setVideoEncParam(encoderparam: HRTCVideoEncParam): number;
    /**
     *
     * @param enable 设置是否默认自动接收新用户视频流。在加入房间前调用。
     */
    setDefaultMuteAllRemoteVideoStreams(enable: boolean): number;
    /**
     *
     * @param enable 设置是否开启远端流分辨率自适应。默认开启
     */
    setRemoteVideoAdjustResolution(enable: boolean): number;
    /**
     * 设置是否开启打点统计。开启打点统计，在initialize前调用
     * @param enable
     */
    enableRtcStats(enable: boolean): number;
    /**
     * 是否激活视频流大小流功能，并设置小流的编码参数。
     * @param enable
     * @param smallVideoParam
     * @returns
     */
    enableSmallVideoStream(enable: boolean, smallVideoParam?: HRTCVideoEncParam): number;
    /**
     * @ignore
     */
    initializePluginManager(): number;
    /**
     * @ignore
     */
    releasePluginManager(): number;
    /**
     * @ignore
     */
    registerPlugin(info: PluginInfo): number;
    /**
     * @ignore
     */
    unregisterPlugin(pluginId: string): number;
    /**
     * @ignore
     */
    getPlugins(): Plugin[];
    /**
     * @ignore
     * @param pluginId
     */
    createPlugin(pluginId: string): Plugin;
    /**
     * @ignore
     * @param pluginId
     * @param enabled
     */
    enablePlugin(pluginId: string, enabled: boolean): number;
    /**
     * @ignore
     * @param pluginId
     * @param param
     */
    setPluginParameter(pluginId: string, param: string): number;
    /**
     * @ignore
     * @param pluginId
     * @param paramKey
     */
    getPluginParameter(pluginId: string, paramKey: string): string;
    /**
     * 音视频设备管理
     */
    /**
     *
     * @param deviceId
     * @returns
     */
    setAudioRecordingDevice(deviceId: string): number;
    /**
     *
     * @returns
     */
    getAudioRecordingDevices(): Array<HRTCDeviceInfo>;
    /**
     *
     * @returns
     */
    getCurrentAudioRecordingDevice(): string;
    /**
     * mute：必选，boolean类型，音频采集设备是否静音，true表示静音，false表示取消静音。
     * @param mute
     */
    setAudioRecordingDeviceMute(mute: boolean): number;
    /**
     * 获取音频采集设备静音状态。
     * @returns
     */
    getAudioRecordingDeviceMute(): boolean;
    /**
     *
     * @param volume
     * @returns
     */
    setAudioRecordingVolume(volume: number): number;
    /**
     * 获取当前音频采集设备音量
     * @returns
     */
    getAudioRecordingVolume(): number;
    /**
     *
     * @param deviceId
     * @returns
     */
    setAudioPlaybackDevice(deviceId: string): number;
    /**
     *
     * @returns
     */
    getAudioPlaybackDevices(): Array<HRTCDeviceInfo>;
    /**
     *
     */
    getCurrentAudioPlaybackDevice(): string;
    /**
     * 设置音频播放设备静音。
     * @param mute
     */
    setAudioPlaybackDeviceMute(mute: boolean): number;
    /**
     * 获取音频播放设备静音状态。
     * @returns
     */
    getAudioPlaybackDeviceMute(): boolean;
    /**
     * 设置音频播放音量。
     * @param volume  volume：必选，number类型，设置音频播放的音量，取值范围为[0,100]
     * @returns
     */
    setAudioPlaybackVolume(volume: number): number;
    /**
     *
     * @returns
     */
    getAudioPlaybackVolume(): number;
    /**
     *
     * @param deviceId
     * @returns
     */
    setVideoDevice(deviceId: string): number;
    /**
     * 获取视频采集设备列表
     * @returns
     */
    getVideoDevices(): Array<HRTCDeviceInfo>;
    /**
     * 获取视频采集设备列表
     * @returns
     */
    getCurrentVideoDevice(): string;
    /**
     * 开启/关闭本地视频采集。
     * @param enable
     * @returns
     */
    enableLocalVideo(enable: boolean): number;
    /**
     * 停止/恢复发送本地视频流
     * @param mute
     * @returns
     */
    muteLocalVideoStream(mute: boolean): number;
    /**
     * 停止/恢复接收指定的远端视频流。
     * @param userId
     * @param mute
     * @returns
     */
    muteRemoteVideoStream(userId: string, mute: boolean): number;
    /**
     * 停止/恢复接收全部远端视频流
     * @param mute
     * @returns number类型，0表示调用成功，其它值表示调用失败
     */
    muteAllRemoteVideoStreams(mute: boolean): number;
    /**
     * 停止/恢复发送本地音频流。
     * @param mute
     * @returns
     */
    muteLocalAudioStream(mute: boolean): number;
    /**
     * 停止/恢复接收指定的远端音频流。
     * @param userId
     * @param mute
     * @returns
     */
    muteRemoteAudioStream(userId: string, mute: boolean): number;
    /**
     * 停止/恢复接收全部远端音频流。
     * @param mute
     * @returns
     */
    muteAllRemoteAudioStreams(mute: boolean): number;
    /**
     * 设置是否关闭默认自动接收新用户音频流。在加入房间前调用。
     * @param mute
     * @returns
     */
    setDefaultMuteAllRemoteAudioStreams(mute: boolean): number;
    /**
     * 设置音频订阅模式。
     * @param mode
     * @returns
     */
    setRemoteAudioMode(mode: HRTCRemoteAudioMode): number;
    /**
     * 开启/关闭本地音频采集。
     * @param enable
     * @returns
     */
    enableLocalAudio(enable: boolean): number;
    /**
     * 设置远端用户音量上报周期。
     * @param interval
     * @returns
     */
    enableUserVolumeNotify(interval: number): number;
    /**
     * 调节音频采集音量。
     * @param volume
     * @returns
     */
    adjustRecordingVolume(volume: number): number;
    /**
     * 调节音频播放音量。
     * @param volume
     * @returns
     */
    adjustPlaybackVolume(volume: number, userId?: string): number;
    /**
     * 设置是否开启系统音频采集、发送，只能在房间内使用
     * @param enable
     * @returns
     */
    setShareComputerSound(enable: boolean): number;
    /**
     * 开启音频自渲染
     * @param localEnable
     * @param remoteEnable
     * @returns
     */
    setExternalAudioFrameOutput(localEnable: boolean, remoteEnable: boolean): number;
    /**
     * 开始播放音频文件，房间内调用。远端用户订阅本端音频流后可以听到此音频
     * @param filePath 音频文件的本地全路径
     * @param playMode 播放模式
     * @param cycle 循环次数，0表示无限循环
     * @param replace 远端模式下面是否需要和麦克风做混音
     */
    startAudioFile(filePath: string, playMode: number, cycle: number, replace: number, startPos?: number): number;
    /**
     * 停止播放音频文件，房间内调用，若角色为“publisher”，不支持调用
     */
    stopAudioFile(): number;
    /**
     * 暂停播放音频文件，房间内调用
     */
    pauseAudioFile(): number;
    /**
     * 恢复播放音频文件，房间内调用
     */
    resumeAudioFile(): number;
    /**
     * 调节音乐文件播放音量
     * @param volume
     */
    adjustAudioFileVolume(volume: number): number;
    /**
     * 获取音乐文件播放音量
     */
    getAudioFileVolume(): number;
    /**
     * 获取音乐文件播放时长
     */
    getAudioFileDuration(): number;
    /**
     * 获取音乐文件播放当前播放进度
     * @returns
     */
    getAudioFilePosition(): number;
    /**
     * 设置音乐文件播放进度
     * @param position
     */
    setAudioFilePosition(position: number): number;
    /**
     * 调节音乐文件的本地播放音量
     * @param volume
     * @returns
     */
    adjustAudioFilePlayoutVolume(volume: number): number;
    /**
     * 调节音乐文件的远端播放音量
     * @param volume
     * @returns
     */
    adjustAudioFilePublishVolume(volume: number): number;
    /**
     * 获取音乐文件的本地播放音量
     * @returns
     */
    getAudioFilePlayoutVolume(): number;
    /**
     * 获取音乐文件的远端播放音量
     * @returns
     */
    getAudioFilePublishVolume(): number;
    /**
     * 获取音效文件的播放音量
     * @returns
     */
    getAudioClipsVolume(): number;
    /**
     * 设置音效文件的播放音量
     * @param volume
     * @returns
     */
    setAudioClipsVolume(volume: number): number;
    /**
     * 获取指定音效文件的播放音量
     * @param sounderId sounderId：指定音效Id
     * @returns
     */
    getVolumeOfAudioClip(sounderId: number): number;
    /**
     * 实时调整音效文件的播放音量
     * @param soundId  soundId：指定音效Id
     * @param volume   volume: 播放音量
     * @returns
     */
    setVolumeOfAudioClip(soundId: number, volume: number): number;
    /**
     * 播放指定音效文件
     * @param soundId 指定音效Id
     * @param filepath 文件路径
     * @param loop 循环播放次数
     * @param pitch 音效的音调，取值范围为 [0.5,2.0]。默认值为 1.0，表示原始音调。取值越小，则音调越低
     * @param pan 音效的空间位置。取值范围为 [-1.0,1.0]
     * @param gain 音效的音量
     * @param publish 是否推送
     * @param startPos 播放起始位置
     * @returns
     */
    playAudioClip(soundId: number, filepath: string, loop: number, pitch: number, pan: number, gain: number, publish: number, startPos: number): number;
    /** */
    stopAudioClip(soundId: number): number;
    /**
     * 停止播放所有音效文件
     * @returns
     */
    stopAllAudioClips(): number;
    /**
     * 将音效文件加载至内存
     * @param soundId 指定音效Id
     * @param filePath 文件路径
     * @returns
     */
    preloadAudioClip(soundId: number, filePath: string): number;
    /**
     *
     * @param soundId
     * @returns
     */
    unloadAudioClip(soundId: number): number;
    /**
     * 暂停音效文件播放
     * @param soundId
     * @returns
     */
    pauseAudioClip(soundId: number): number;
    /**
     * 暂停所有音效文件播放
     * @returns
     */
    pauseAllAudioClips(): number;
    /**
     * 恢复播放指定音效文件
     * @param soundId
     * @returns
     */
    resumeAudioClip(soundId: number): number;
    resumeAllAudioClips(): number;
    getAudioClipCurrentPosition(soundId: number): number;
    setAudioClipPosition(soundId: number, position: number): number;
    getAudioClipDuration(filePath: string): number;
    startNetworkTest(config: HRTCNetworkTestConfig): number;
    stopNetworkTest(): number;
    getDeviceId(): string;
    /**
     * 桌面共享
     */
    /**
     *
     * @param type
     * @returns
     */
    getScreenCaptureSources(type: HRTCScreenCaptureIconType): HRTCScreenCaptureSourceInfos;
    /**
     *
     * @param info
     * @param optionalInfo
     * @returns
     */
    selectScreenCaptureTarget(info: HRTCScreenCaptureSourceInfo, optionalInfo: HRTCSrceenCaptureOptionalInfo): number;
    /**
     * 方法调用成功
     * @returns
     */
    startScreenCapture(): number;
    /**
     * 停止屏幕共享
     * @returns
     */
    stopScreenCapture(): number;
    startRemoteSubStreamView(userId: string, view: Element): number;
    stopRemoteSubStreamView(userId: string): number;
    setRemoteSubStreamViewDisplayMode(userId: string, viewMode: HRTCVideoDisplayMode): number;
    setScreenSmooth(enable: boolean): number;
    setRemoteSubStreamViewMirrorMode(userId: string, enable: boolean): number;
    addExcludedShareWindow(view: number): number;
    removeExcludedShareWindow(view: number): number;
    removeAllExcludedShareWindow(): number;
    loadVoiceActivityDetectionModel(modelPath: string): number;
    unloadVoiceActivityDetectionModel(): number;
    setSubStreamEncParam(encoderParams: HRTCSubStreamEncParam): number;
    setVideoEncodeResolutionMode(resolutionMode: HRTCVideoEncodeResolutionMode): number;
    setExternalDataFrameOutput(localEnable: boolean, remoteEnable: boolean): number;
}
/** The HRTCEngine interface. */
declare interface HRTCEngine {
    /**
     * Reports a warning during SDK runtime.
     * @param cb.warn Warning code.
     * @param cb.msg The warning message.
     */
    on(evt: 'warning', cb: (warn: number, msg: string) => void): this;
    /** Reports an error during SDK runtime.
     * @param cb.err Error code.
     * @param cb.msg The error message.
     */
    on(evt: 'error', cb: (err: number, msg: string) => void): this;
    /** Occurs when a user joins a specified room.
     * {@link joinedRoom}
     * method until the SDK triggers this callback.
     */
    on(evt: 'joinedRoom', cb: (roomId: string, userId: number) => void): this;
    /**
     * 本地用户重新加入事件，本地用户因网络中断的原因，重新加入房间后会收到该事件通知
     * @param evt
     * @param cb
     */
    on(evt: 'rejoinedRoom', cb: (roomId: string, userId: string) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'connectionStateChanged', cb: (state: HRTCConnStateTypes, reason: HRTCConnChangeReason, description: string) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'joinRoomFailure', cb: (err: number, msg: string) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'leaveRoom', cb: (reason: HRTCLeaveReason, stats: HRTCStatsInfo) => void): this;
    /**
     * @param
     * @param evt
     * @param cb
     */
    on(evt: 'userJoined', cb: (roomId: string, userId: string, userName: string) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'userOffline', cb: (roomId: string, userId: string, reason: number) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'roleChanged', cb: (roomId: string, oldRole: number, newRole: number) => void): this;
    /**
     * @param evt 远端用户音频状态已改变事件通知
     * @param cb
     */
    on(evt: 'remoteAudioStateChanged', cb: (roomId: string, userId: string, state: HRTCRemoteAudioStreamState, reason: HRTCRemoteAudioStreamStateReason) => void): this;
    /**
     * @param evt 远端用户视频状态已改变事件通知
     * @param cb
     */
    on(evt: 'remoteVideoStateChanged', cb: (roomId: string, userId: string, state: HRTCRemoteVideoStreamState, reason: HRTCRemoteVideoStreamStateReason) => void): this;
    /**
     * @param evt 远端用户麦克风状态已改变事件通知
     * @param cb
     */
    on(evt: 'remoteMicrophoneStateChanged', cb: (userId: string, state: HRTCRemoteMicState) => void): this;
    /**
     * @param evt 媒体渲染成功的事件通知
     * @param cb
     */
    on(evt: 'renderSuccess', cb: (userId: string, isAux: number) => void): this;
    /**
     * @param evt 远端音频流第一帧解码成功事件通知
     * @param cb
     */
    on(evt: 'firstRemoteAudioDecoded', cb: (userId: string, elapsed: number) => void): this;
    /**
     *
     * @param evt 接收到第一帧远端视频流并解码成功的事件通知
     * @param cb
     */
    on(evt: 'firstRemoteVideoDecoded', cb: (roomId: string, userId: string, width: number, height: number) => void): this;
    /**
     *
     * @param evt 本地音频首帧发送事件通知
     * @param cb
     */
    on(evt: 'firstLocalAudioFrame', cb: (elapsed: number) => void): this;
    /**
     *
     * @param evt 本地视频首帧发送事件通知
     * @param cb
     */
    on(evt: 'firstLocalVideoFrame', cb: (elapsed: number) => void): this;
    /**
     *
     * @param evt 本地/远端的音频流统计信息的事件通知
     * @param cb
     */
    on(evt: 'audioStats', cb: (localStats: Array<HRTCLocalAudioStats>, remoteStats: Array<HRTCRemoteAudioStats>) => void): this;
    /**
     *
     * @param evt 本地/远端的视频流统计信息的事件通知
     * @param cb
     */
    on(evt: 'videoStats', cb: (localStats: Array<HRTCLocalVideoStats>, remoteStats: Array<HRTCRemoteVideoStats>) => void): this;
    /**
     * volume：number类型，音量值。
     * muted：number类型，是否静音，用于区分是没有声音还是关闭音频采集。
     * @param evt 本地音量变更通知
     * @param cb
     */
    on(evt: 'localVolumeChanged', cb: (volume: number, muted: number) => void): this;
    /**
     * 本地用户视频状态已改变事件通知
     * @param evt
     * @param cb
     */
    on(evt: 'localVideoStateChanged', cb: (state: HRTCLocalVideoStreamState, reason: HRTCLocalVideoStreamStateReason) => void): this;
    /**
     * 本地用户音频状态已改变事件通知
     * @param evt
     * @param cb
     */
    on(evt: 'localAudioStateChanged', cb: (state: HRTCLocalAudioStreamState, reason: HRTCLocalAudioStreamStateReason) => void): this;
    /**
     * 音频设备播放音量改变的事件通知
     * @param evt
     * @param cb
     */
    on(evt: 'deviceVolumeChanged', cb: (state: HRTCDeviceType, volume: number, muted: number) => void): this;
    /**
     * 设备状态发生改变，触发此事件通知
     * @param evt
     * @param cb
     */
    on(evt: 'deviceStateChanged', cb: (deviceId: string, deviceType: HRTCDeviceType, deviceState: HRTCDeviceState) => void): this;
    /**
     * 签名到期时上报的事件通知
     * @param evt
     * @param cb
     */
    on(evt: 'signatureExpired', cb: () => void): this;
    /**
     * 远端用户音量统计的事件通知
     * @param evt
     * @param cb
     */
    on(evt: 'userVolumeStats', cb: (volumes: Array<HRTCVolumeInfo>, userVolumesCount: number, totalVolume: number) => void): this;
    /**
     * RTCStats统计数据上报。
     * @param evt
     * @param cb
     */
    on(evt: 'rtcStats', cb: (rtcStats: HRtcStatsInfo_All) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'audioClipFinished', cb: (soundId: number) => void): this;
    /**
     * 音乐文件播放状态变更通知。
     * @param evt
     * @param cb
     */
    on(evt: 'audioFileStateChanged', cb: (state: HRTCAudioFileState, reason: HRTCAudioFileReason, value: number) => void): this;
    /**
     * level：HRTCNetworkQualityLevel类型，网络质量水平，值越大，网络质量越好
     * 通话前本地用户的网络质量水平上报通知
     * @param evt
     * @param cb
     */
    on(evt: 'networkTestQuality', cb: (level: HRTCNetworkQualityLevel) => void): this;
    /**
     * 通话前本地用户的网络质量分析数据上报通知
     * @param evt
     * @param cb
     */
    on(evt: 'networkTestResult', cb: (testResult: HRTCNetworkTestResult) => void): this;
    /**
     * 音频文件播放结束，触发此回调
     * @param evt
     * @param cb
     */
    on(evt: 'audioFileFinished', cb: () => void): this;
    /**
     * result: 播放音频文件事件结果
     * @param evt
     * @param cb
     */
    on(evt: 'startAudioFile', cb: (result: number) => void): this;
    /**
     * result: 停止播放音频文件的事件结果
     * @param evt
     * @param cb
     */
    on(evt: 'stopAudioFile', cb: (result: number) => void): this;
    /**
     * result: 暂停播放音频文件的事件结果
     * @param evt
     * @param cb
     */
    on(evt: 'pauseAudioFile', cb: (result: number) => void): this;
    /**
     * result: 恢复播放音频文件的事件结果
     * @param evt
     * @param cb
     */
    on(evt: 'resumeAudioFile', cb: (result: number) => void): this;
    /**
     * 通话中本地/远端用户的网络质量水平上报通知
     * @param evt
     * @param cb
     */
    on(evt: 'networkQuality', cb: (localQuality: Array<HRTCQualityInfo>, remoteQuality: Array<HRTCQualityInfo>) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'logUploadResult', cb: (result: number) => void): this;
    /**
     *
     * @param evt
     * @param cb
     */
    on(evt: 'logUploadProgress', cb: (progress: number) => void): this;
    on(evt: 'userSubStreamAvailable', cb: (roomId: string, userId: string, available: boolean) => void): this;
    on(evt: 'screenCaptureStarted', cb: () => void): this;
    on(evt: 'screenCaptureStoped', cb: (reason: number) => void): this;
    /**
     * 共享流详情，2s触发一次回调
     * @param evt
     * @param cb
     */
    on(evt: 'subStreamStats', cb: (localStats: Array<HRTCLocalVideoStats>, remoteStats: Array<HRTCRemoteVideoStats>) => void): this;
    on(evt: string, listener: Function): this;
}
export default HRTCEngine;
