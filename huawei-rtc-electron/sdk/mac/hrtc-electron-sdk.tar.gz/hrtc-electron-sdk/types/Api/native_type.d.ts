/**
 * interface
 *
 */
/**
 * enum
 */
import { PluginInfo } from './plugin';
export declare enum HRTCLogLevel {
    HRTC_LOG_LEVEL_ERROR = 0,
    HRTC_LOG_LEVEL_WARNING = 1,
    HRTC_LOG_LEVEL_INFO = 2,
    HRTC_LOG_LEVEL_DEBUG = 3
}
export declare enum HRTCConnStateTypes {
    HRTC_CONN_DISCONNECTED = 0,
    HRTC_CONN_CONNECTING = 1,
    HRTC_CONN_CONNECTED = 2,
    HRTC_CONN_RECONNECTING = 3,
    HRTC_CONN_FAILED = 4
}
export declare enum HRTCConnChangeReason {
    HRTC_CONN_CHANGED_CONNECTING = 0,
    HRTC_CONN_CHANGED_JOIN_SUCCESS = 1,
    HRTC_CONN_CHANGED_RECONNECTING = 2,
    HRTC_CONN_CHANGED_RECONNECT_SUCCESS = 3,
    HRTC_CONN_CHANGED_JOIN_FAILED = 4,
    HRTC_CONN_CHANGED_RECONNCET_FAILED = 5,
    HRTC_CONN_CHANGED_INTERRUPTED = 6,
    HRTC_CONN_CHANGED_KEEP_ALIVE_TIMEOUT = 7,
    HRTC_CONN_CHANGED_LEAVE_ROOM = 8,
    HRTC_CONN_CHANGED_JOIN_ROOM_SERVER_ERROR = 9,
    HRTC_CONN_CHANGED_SFU_BREAKDOWN = 10,
    HRTC_CONN_CHANGED_JOIN_ROOM_AUTH_FAILED = 11,
    HRTC_CONN_CHANGED_JOIN_ROOM_AUTH_RETRY = 12,
    HRTC_CONN_CHANGED_JOIN_ROOM_AUTH_CLOCK_SYNC = 13,
    HRTC_CONN_CHANGED_JOIN_ROOM_URL_NOT_RIGHT = 14,
    HRTC_CONN_CHANGED_JOIN_ROOM_SERVICE_UNREACHABLE = 15,
    HRTC_CONN_CHANGED_INTERNAL_ERROR = 16,
    HRTC_CONN_CHANGED_KICKED_OFF = 17,
    HRTC_CONN_CHANGED_SIGNATURE_EXPIRED = 18,
    HRTC_CONN_REASON_USER_REMOVED = 19,
    HRTC_CONN_REASON_ROOM_DISMISSED = 20,
    HRTC_CONN_CHANGED_REGION_NOT_COVERED = 21
}
export declare enum HRTCLeaveReason {
    HRTC_LEAVE_REASON_USER_LEAVE_ROOM = 0,
    HRTC_LEAVE_REASON_SERVER_ERROR = 1,
    HRTC_LEAVE_REASON_BREAKDOWN = 2,
    HRTC_LEAVE_REASON_SERVICE_UNREACHABLE = 3,
    HRTC_LEAVE_REASON_INTERNAL_ERROR = 4,
    HRTC_LEAVE_REASON_KICKED_OFF = 5,
    HRTC_LEAVE_REASON_SIGNATURE_EXPIRED = 6,
    HRTC_LEAVE_REASON_RECONNECT_FAILED = 7,
    HRTC_LEAVE_REASON_NETWORK_TEST = 8,
    HRTC_LEAVE_REASON_USER_REMOVED = 9,
    HRTC_LEAVE_REASON_ROOM_DISMISSED = 10,
    HRTC_LEAVE_REASON_REGION_NOT_COVERED = 11
}
export declare enum HRTCRoleType {
    HRTC_ROLE_TYPE_JOINER = 0 /**< 双向流角色，例如主播加入 */,
    HRTC_ROLE_TYPE_PUBLISER = 1 /**< 发布流角色，例如广播 */,
    HRTC_ROLE_TYPE_PLAYER = 2 /**< 接收流角色，例如观众 */
}
export declare enum HRTCDisplayMode {
    HRTC_VIDEO_DISPLAY_MODE_HIDDEN = 0,
    HRTC_VIDEO_DISPLAY_MODE_FIT = 1,
    HRTC_VIDEO_DISPLAY_MODE_FILL = 2
}
export declare enum HRTCStreamType {
    HRTC_STREAM_TYPE_LD = 0,
    HRTC_STREAM_TYPE_SD = 1,
    HRTC_STREAM_TYPE_HD = 2,
    HRTC_STREAM_TYPE_FHD = 3
}
export declare enum HRTCMediaType {
    HRTC_MEDIA_TYPE_AUDIO = 0,
    HRTC_MEDIA_TYPE_VIDEO = 1
}
export declare enum HRTCVideoStreamType {
    HRTC_VIDEO_STREAM_TYPE_BIG = 0,
    HRTC_VIDEO_STREAM_TYPE_SMALL = 1
}
export declare enum RTCVideoMirrorType {
    enable = 0,
    disable = 1
}
export declare enum HRTCVideoMirrorType {
    HRTC_VIDEO_MIRROR_TYPE_AUTO = 0,
    HRTC_VIDEO_MIRROR_TYPE_ENABLE = 1,
    HRTC_VIDEO_MIRROR_TYPE_DISABLE = 2
}
export declare enum HRTCRemoteAudioStreamState {
    HRTC_REMOTE_AUDIO_STATE_STOPPED = 0,
    HRTC_REMOTE_AUDIO_STATE_STARTING = 1
}
export declare enum HRTCRemoteMicState {
    HRTC_REMOTE_MIC_STATE_UNMUTE = 0,
    HRTC_REMOTE_MIC_STATE_MUTE = 1
}
export declare enum HRTCRemoteAudioStreamStateReason {
    HRTC_REMOTE_AUDIO_REASON_REMOTE_OFFLINE = 0,
    HRTC_REMOTE_AUDIO_REASON_REMOTE_MUTED = 1,
    HRTC_REMOTE_AUDIO_REASON_REMOTE_UNMUTED = 2
}
export declare enum HRTCRemoteVideoStreamState {
    HRTC_REMOTE_VIDEO_STATE_STOPPED = 0,
    HRTC_REMOTE_VIDEO_STATE_STARTING = 1
}
export declare enum HRTCRemoteVideoStreamStateReason {
    HRTC_REMOTE_VIDEO_REASON_REMOTE_OFFLINE = 0,
    HRTC_REMOTE_VIDEO_REASON_REMOTE_MUTED = 1,
    HRTC_REMOTE_VIDEO_REASON_REMOTE_UNMUTED = 2
}
export declare enum NodeRenderType {
    NODE_RENDER_TYPE_LOCAL = 0,
    NODE_RENDER_TYPE_REMOTE = 1,
    NODE_RENDER_TYPE_DEVICE_TEST = 2
}
export declare enum HRTCVideoImageFormat {
    HRTC_VIDEO_IMAGE_FORMAT_YUV420P = 0,
    HRTC_VIDEO_IMAGE_FORMAT_RGBA = 3
}
declare enum HRTCVideoImageBufferType {
    HRTC_VIDEO_IMAGE_BUFFER_BYTE_ARRAY = 0,
    HRTC_VIDEO_IMAGE_BUFFER_TEXTURE = 1
}
export declare enum HRTCRemoteAudioMode {
    HRTC_REMOTE_AUDIO_TOPN_OF_ALL = 0,
    HRTC_REMOTE_AUDIO_SUBSCRIBED = 1,
    HRTC_REMOTE_AUDIO_TOP_THREE = 2
}
export declare enum HRTCLocalVideoStreamState {
    HRTC_LOCAL_VIDEO_STATE_STOPPED = 0,
    HRTC_LOCAL_VIDEO_STATE_CAPTURING = 1,
    HRTC_LOCAL_VIDEO_STATE_FAILED = 2
}
export declare enum HRTCLocalVideoStreamStateReason {
    HRTC_LOCAL_VIDEO_REASON_ERROR_OK = 0,
    HRTC_LOCAL_VIDEO_REASON_ERROR_FAILURE = 1,
    HRTC_LOCAL_VIDEO_REASON_ERROR_CAPTURE_FAILURE = 2,
    HRTC_LOCAL_VIDEO_REASON_ERROR_STOP_FAILURE = 3
}
export declare enum HRTCLocalAudioStreamState {
    HRTC_LOCAL_AUDIO_STATE_STOPPED = 0,
    HRTC_LOCAL_AUDIO_STATE_RECORDING = 1,
    HRTC_LOCAL_AUDIO_STATE_FAILED = 2
}
export declare enum HRTCLocalAudioStreamStateReason {
    HRTC_LOCAL_AUDIO_REASON_ERROR_OK = 0,
    HRTC_LOCAL_AUDIO_REASON_ERROR_FAILURE = 1,
    HRTC_LOCAL_AUDIO_REASON_ERROR_RECORD_FAILURE = 2,
    HRTC_LOCAL_AUDIO_REASON_ERROR_STOP_FAILURE = 3
}
export declare enum HRTCDeviceType {
    HRTC_DEVTYPE_AUDIO_PLAYBACK = 0,
    HRTC_DEVTYPE_AUDIO_RECORDING = 1,
    HRTC_DEVTYPE_VIDEO_CAPTURE = 2
}
export declare enum HRTCDeviceState {
    HRTC_DEVICE_STATE_ACTIVE = 0,
    HRTC_DEVICE_STATE_DISABLED = 1,
    HRTC_DEVICE_STATE_UNPLUGGED = 2
}
export declare enum HRTCAudioFileState {
    HRTC_AUDIO_FILE_OPEN_COMPLETED = 0,
    HRTC_AUDIO_FILE_OPENING = 1,
    HRTC_AUDIO_FILE_IDLE = 2,
    HRTC_AUDIO_FILE_PLAYING = 3,
    HRTC_AUDIO_FILE_PLAY_COMPLETED = 4,
    HRTC_AUDIO_FILE_PAUSED = 5,
    HRTC_AUDIO_FILE_STOPPED = 6,
    HRTC_AUDIO_FILE_FAILED = 7,
    HRTC_AUDIO_FILE_POSITION_UPDATE = 8,
    HRTC_AUDIO_FILE_STATE_UNKNOWN = 9
}
export declare enum HRTCAudioFileReason {
    HRTC_AUDIO_FILE_REASON_NONE = 0,
    HRTC_AUDIO_FILE_REASON_URL_NOT_FOUND = 1,
    HRTC_AUDIO_FILE_REASON_CODEC_NOT_SUPPORTED = 2,
    HRTC_AUDIO_FILE_REASON_INVALID_ARGUMENTS = 3,
    HRTC_AUDIO_FILE_REASON_SRC_BUFFER_UNDERFLOW = 4,
    HRTC_AUDIO_FILE_REASON_INTERNAL = 5,
    HRTC_AUDIO_FILE_REASON_INVALID_STATE = 6,
    HRTC_AUDIO_FILE_REASON_NO_RESOURCE = 7,
    HRTC_AUDIO_FILE_REASON_OBJ_NOT_INITIALIZED = 8,
    HRTC_AUDIO_FILE_REASON_INVALID_CONNECTION_STATE = 9,
    HRTC_AUDIO_FILE_REASON_UNKNOWN_STREAM_TYPE = 10,
    HRTC_AUDIO_FILE_REASON_VIDEO_RENDER_FAILED = 11,
    HRTC_AUDIO_FILE_REASON_INVALID_MEDIA_SOURCE = 12,
    HRTC_AUDIO_FILE_REASON_UNKNOWN = 13
}
export declare enum HRTCNetworkQualityLevel {
    HRTC_NETWORK_QUALITY_UNKNOWN = 0,
    HRTC_NETWORK_QUALITY_EXCELLENT = 1,
    HRTC_NETWORK_QUALITY_GOOD = 2,
    HRTC_NETWORK_QUALITY_POOR = 3,
    HRTC_NETWORK_QUALITY_BAD = 4,
    HRTC_NETWORK_QUALITY_VBAD = 5
}
declare enum HRTCNetworkTestState {
    HRTC_NETWORK_TEST_OK = 0,
    HRTC_NETWORK_TEST_FAIL = 1
}
export declare enum HRTCScreenCaptureType {
    HRTC_SCREEN_CAPTURE = 0,
    HRTC_WINDOW_CAPTURE = 1
}
export declare enum HRTCScreenCaptureIconType {
    HRTC_SCREENCAPTURE_SMALL_ICON = 0,
    HRTC_SCREENCAPTURE_BIG_ICON = 1
}
export declare enum HRTCVideoDisplayMode {
    HRTC_VIDEO_DISPLAY_MODE_HIDDEN = 0,
    HRTC_VIDEO_DISPLAY_MODE_FIT = 1,
    HRTC_VIDEO_DISPLAY_MODE_FILL = 2,
    HRTC_VIDEO_DISPLAY_ADAPT = 3
}
export declare enum HRTCVideoEncodeResolutionMode {
    HRTC_VIDEO_ENCODE_RESOLUTION_MODE_NONE = 0,
    HRTC_VIDEO_ENCODE_RESOLUTION_MODE_CONST_RATIO = 1
}
export declare enum NodeMediaType {
    NODE_MEDIA_TYPE_VIDEO = 0,
    NODE_MEDIA_TYPE_SCREEN = 1
}
/**
 * joinroom object
 *
 */
export interface Joinroom_UserInfo {
    role: number;
    userId: string;
    userName: string;
    signature: string;
    ctime: number;
    optionInfo?: string;
}
/**
 * HR initialize
 */
export interface logInfoParam {
    level: HRTCLogLevel;
    path: string;
}
export interface HRTCStatsInfo {
    mildlyFrozenCounts: number;
    severelyFrozenCounts: number;
    totalMildlyFrozenTime: number;
    totalSeverelyFrozenTime: number;
    totalActiveTime: number;
}
export interface RendererOptions {
    append: boolean;
}
export interface HRTCVideoEncParam {
    streamType: HRTCStreamType;
    width: number;
    height: number;
    frameRate: number;
    bitrate: number;
    minFrameRate?: number;
    minBitrate?: number;
    disableAdjustRes?: boolean;
}
export interface HRTCLocalVideoStats {
    width: number;
    height: number;
    bitRate: number;
    frameRate: number;
    packetLoss: number;
    delay: number;
    jitter: number;
    bytes: number;
    sendFrameRate: number;
}
export interface HRTCRemoteVideoStats {
    userId: string;
    width: number;
    height: number;
    buffered: number;
    bitRate: number;
    frameRate: number;
    packetLoss: number;
    delay: number;
    jitter: number;
    bytes: number;
    rendererOutputFrameRate: number;
    totalFrozenTime: number;
    frozenRate: number;
}
export interface HRTCLocalAudioStats {
    sampleRate: number;
    channels: number;
    sendVEL: number;
    bitRate: number;
    packetLoss: number;
    delay: number;
    jitter: number;
    bytes: number;
}
export interface HRTCRemoteAudioStats {
    userId: string;
    sampleRate: number;
    channels: number;
    recvVEL: number;
    bitRate: number;
    packetLoss: number;
    delay: number;
    jitter: number;
    bytes: number;
    totalFrozenTime: number;
    frozenRate: number;
}
export interface HRTCImageBufferFormat {
    format: HRTCVideoImageFormat;
    bufferType: HRTCVideoImageBufferType;
}
export interface HRTCDeviceInfo {
    deviceId: string;
    deviceName: string;
}
export interface HRTCVolumeInfo {
    userId: string;
    volume: number;
}
export interface HRtcStatsInfo_All {
    cpuAppUsage: number;
    cpuTotalUsage: number;
    memoryAppUsageInKbytes: number;
    memoryAppUsageRatio: number;
    memoryTotalUsageRatio: number;
    gatewayRtt: number;
    sendBytes: number;
    sendVideoBytes: number;
    sendAudioBytes: number;
    receiveBytes: number;
    receiveVideoBytes: number;
    receiveAudioBytes: number;
    sendBitRate: number;
    sendVideoBitRate: number;
    sendAudioBitRate: number;
    receiveBitRate: number;
    receiveVideoBitRate: number;
    receiveAudioBitRate: number;
    sendLossRate: number;
    receiveLossRate: number;
    lastmileDelay: number;
}
export interface HRTCNetworkTestResultParam {
    bitRate: number;
    packetLoss: number;
    delay: number;
    jitter: number;
}
export interface HRTCNetworkTestResult {
    testState: HRTCNetworkTestState;
    uplinkResult: HRTCNetworkTestResultParam;
    downlinkResult: HRTCNetworkTestResultParam;
}
export interface HRTCQualityInfo {
    userId: string;
    width: number;
    height: number;
    level: HRTCNetworkQualityLevel;
}
export interface HRTCNetworkTestConfig {
    userId: string;
    roomId: string;
    signature?: string;
    ctime?: number;
    enableUplinkTest: number;
    enableDownlinkTest: number;
    expectedUplinkBitrate: number;
    expectedDownlinkBitrate: number;
}
export interface HRTCMediaOptions {
    autoSubscribeAudio: boolean;
    autoSubscribeVideo: boolean;
    mediaType: HRTCMediaType;
}
export interface HRTCScreenCaptureSourceInfo {
    sourceId: string | number;
    sourceName: string;
    type: HRTCScreenCaptureType;
    icon: Uint8Array;
}
export interface HRTCScreenCaptureSourceInfos {
    count: number;
    sourceInfos: Array<HRTCScreenCaptureSourceInfo>;
}
interface HRTCRect {
    left: number;
    top: number;
    right: number;
    bottom: number;
}
export interface HRTCSrceenCaptureOptionalInfo {
    disableCaptureMouse?: boolean;
    rect?: HRTCRect;
}
export interface HRTCSubStreamEncParam {
    frameRate: number;
    width: number;
    height: number;
    bitrate: number;
}
/**
 * custom object
 */
export interface Joinroom_SelfInfo {
    userId: string;
}
export interface Joinroom_MediaType {
    MEDIA_VIDEO: string;
    MEDIA_SCREEN: string;
}
/**
 * interface for c++ addon (.node)
 * @ignore
 */
export interface NodeRtcEngine {
    /**
     * 设置日志文件，日志级别等日志相关参数
     * @param enable 必选，boolean类型，是否输出日志，true表示输出日志，false表示不输出日志。
     * @param logInfo 必选，HRTCLogInfo类型，日志相关参数。
     */
    setLogParam(enable: boolean, logInfo: logInfoParam): number;
    /**
     * 日志上传接口
     */
    logUpload(): number;
    /**
     * 更新签名
     * @param newSig 必选，string类型，新的签名字符串
     * @param ctime 必选，number类型，过期时间的时间戳，单位秒
     */
    renewSignature(newSig: string, ctime: number): number;
    /**
     * 以JSON格式设置多个SDK指定参数。通过可扩展的JSON字符数组实现多个参数设置
     * @param config
     */
    setParameters(config: string): number;
    /**
     * @ignore
     */
    initialize(appId: string, domain: string): number;
    /**
     * @ignore
     */
    getVersion(): string;
    /**
     * @ignore
     */
    joinRoom(roomId: string, userinfo: Joinroom_UserInfo, option: HRTCMediaOptions): number;
    /**
     * @ignore
     */
    leaveRoom(): number;
    /**
     * @ignore
     */
    release(): number;
    /**
     * @ignore
     */
    setUserRole(roletype: HRTCRoleType): number;
    /**
     * @ignore
     */
    setAddonLogFile(filepath: string): number;
    /**
     * @ignore
     */
    onEvent(event: string, callback: Function): void;
    /**
     * frameFormat 默认值为yuv\HRTC_VIDEO_FRAME_BUFFER_BYTE_ARRAY
     * @param localenable
     * @param remoteenable
     */
    setExternalVideoFrameOutput(localenable: boolean, remoteenable: boolean, frameFormat?: HRTCImageBufferFormat): number;
    /**
     * Video Preview
     */
    startPreview(): number;
    /**
     *
     */
    stopPreview(): number;
    /**
     * 订阅
     * @param userId
     * @param view
     * @param disableAdjustRes
     */
    startRemoteStreamView(userId: string, streamType: HRTCStreamType, disableAdjustRes: boolean): number;
    /**
     * 取消订阅
     * @param userId
     */
    stopRemoteStreamView(userId: string): number;
    /**
     * @ignore
     */
    registerDeliverFrame(callback: Function): number;
    /**
     * @ignore
     */
    setVideoRenderFPS(fps: number): number;
    /**
     * @ignore
     */
    enableStreamRecvPacketNotify(enable: boolean, timeInterval: number): number;
    /**
     * @ignore
     */
    enableHowlingDetect(enable: boolean): number;
    /**
     *
     * @param encoderparam
     */
    setVideoEncParam(encoderparam: HRTCVideoEncParam): number;
    /**
     *
     * @param userId
     * @param type
     */
    setRemoteVideoStreamType(userId: string, type: HRTCVideoStreamType): number;
    /**
     *
     * @param type
     */
    setPriorRemoteVideoStreamType(type: HRTCVideoStreamType): number;
    /**
     *
     * @param mirrorType
     */
    setVideoEncoderMirror(mirrorType: HRTCVideoMirrorType): number;
    /**
     *
     * @param enable
     */
    setDefaultMuteAllRemoteVideoStreams(enable: boolean): number;
    /**
     *
     * @param enable
     */
    setRemoteVideoAdjustResolution(enable: boolean): number;
    /**
     *
     * @param enable
     */
    enableRtcStats(enable: boolean): number;
    /**
     *
     * @param enable
     * @param smallVideoParam
     */
    enableSmallVideoStream(enable: boolean, smallVideoParam?: HRTCVideoEncParam): number;
    /**
     * 音视频设备管理
     */
    /**
     *
     * @param deviceId
     */
    setAudioRecordingDevice(deviceId: string): number;
    /**
     *
     */
    getAudioRecordingDevices(): Array<HRTCDeviceInfo>;
    /**
     *
     */
    getCurrentAudioRecordingDevice(): string;
    /**
     *
     * @param mute
     */
    setAudioRecordingDeviceMute(mute: boolean): number;
    /**
     *
     */
    getAudioRecordingDeviceMute(): boolean;
    /**
     *
     * @param volume
     */
    setAudioRecordingVolume(volume: number): number;
    /**
     *
     */
    getAudioRecordingVolume(): number;
    /**
     *
     * @param deviceId
     */
    setAudioPlaybackDevice(deviceId: string): number;
    /**
     *
     */
    getAudioPlaybackDevices(): Array<HRTCDeviceInfo>;
    /**
     *
     */
    getCurrentAudioPlaybackDevice(): string;
    /**
     *
     * @param mute
     */
    setAudioPlaybackDeviceMute(mute: boolean): number;
    /**
     *
     */
    getAudioPlaybackDeviceMute(): boolean;
    /**
     *
     * @param volume
     */
    setAudioPlaybackVolume(volume: number): number;
    /**
     *
     */
    getAudioPlaybackVolume(): number;
    /**
     *
     * @param deviceId
     */
    setVideoDevice(deviceId: string): number;
    /**
     *
     */
    getVideoDevices(): Array<HRTCDeviceInfo>;
    /**
     * 获取当前视频采集设备。
     */
    getCurrentVideoDevice(): string;
    /**
     * 开启/关闭本地视频采集。
     * @param enable
     */
    enableLocalVideo(enable: boolean): number;
    /**
     * 停止/恢复发送本地视频流
     * @param mute
     */
    muteLocalVideoStream(mute: boolean): number;
    /**
     * 停止/恢复接收指定的远端视频流。
     * @param userId
     * @param mute
     */
    muteRemoteVideoStream(userId: string, mute: boolean): number;
    /**
     * 停止/恢复接收全部远端视频流
     * @param mute
     */
    muteAllRemoteVideoStreams(mute: boolean): number;
    /**
     * 停止/恢复发送本地音频流。
     * @param mute
     */
    muteLocalAudioStream(mute: boolean): number;
    /**
     * 停止/恢复接收指定的远端音频流。
     * @param userId
     * @param mute
     */
    muteRemoteAudioStream(userId: string, mute: boolean): number;
    /**
     * 停止/恢复接收全部远端音频流。
     * @param mute
     */
    muteAllRemoteAudioStreams(mute: boolean): number;
    /**
     * 设置是否关闭默认自动接收新用户音频流。在加入房间前调用。
     * @param mute
     */
    setDefaultMuteAllRemoteAudioStreams(mute: boolean): number;
    /**
     * 设置音频订阅模式。
     * @param mode
     */
    setRemoteAudioMode(mode: HRTCRemoteAudioMode): number;
    /**
     * 开启/关闭本地音频采集。
     * @param enable
     */
    enableLocalAudio(enable: boolean): number;
    /**
     * 设置远端用户音量上报周期。
     * @param interval
     */
    enableUserVolumeNotify(interval: number): number;
    /**
     * 调节音频采集音量。
     * @param volume
     */
    adjustRecordingVolume(volume: number): number;
    /**
     * 调节音频播放音量。
     * @param enable
     */
    adjustPlaybackVolume(volume: number, userId?: string): number;
    /**
     * 设置是否开启系统音频采集、发送，只能在房间内使用
     * @param enable
     */
    setShareComputerSound(enable: boolean): number;
    /**
     * 开启音频自渲染
     * @param localEnable localEnable：必选，boolean类型，开启本地音频自渲染，默认sdk渲染。
     * @param remoteEnable remoteEnable：必选，boolean类型，开启远端音频自渲染，默认sdk渲染
     */
    setExternalAudioFrameOutput(localEnable: boolean, remoteEnable: boolean): number;
    /**
     * 注册音频自渲染回掉数据接口  setExternalAudioFrameOutput该接口开启或关闭数据回调
     * @ignore
     */
    registerDeliverAudioFrame(callback: Function): number;
    /**
     * @ignore
     */
    initializePluginManager(): number;
    /**
     * @ignore
     */
    releasePluginManager(): number;
    /**
     * @ignore
     */
    getPlugins(): Array<{
        id: string;
    }>;
    /**
     * @ignore
     */
    registerPlugin(pluginInfo: PluginInfo): number;
    /**
     * @ignore
     */
    unregisterPlugin(pluginId: string): number;
    /**
     * @ignore
     */
    enablePlugin(pluginId: string, enabled: boolean): number;
    /**
     * @ignore
     */
    setPluginParameter(pluginId: string, param: string): number;
    /**
     * @ignore
     */
    getPluginParameter(pluginId: string, paramKey: string): string;
    /**
     * 开始播放音频文件，房间内调用。远端用户订阅本端音频流后可以听到此音频
     * @param filePath 音频文件的本地全路径
     * @param playMode 播放模式
     * @param cycle 循环次数，0表示无限循环
     * @param replace 远端模式下面是否需要和麦克风做混音
     * @param startPos
     */
    startAudioFile(filePath: string, playMode: number, cycle: number, replace: number, startPos?: number): number;
    /**
     * 停止播放音频文件，房间内调用，若角色为“publisher”，不支持调用
     */
    stopAudioFile(): number;
    /**
     * 暂停播放音频文件，房间内调用
     */
    pauseAudioFile(): number;
    /**
     * 恢复播放音频文件，房间内调用
     */
    resumeAudioFile(): number;
    /**
     * 调节音乐文件播放音量
     * @param volume
     */
    adjustAudioFileVolume(volume: number): number;
    /**
     * 获取音乐文件播放音量
     */
    getAudioFileVolume(): number;
    /**
     * 获取音乐文件播放时长
     */
    getAudioFileDuration(): number;
    /**
     * 获取音乐文件播放当前播放进度
     */
    getAudioFilePosition(): number;
    /**
     * 设置音乐文件播放进度
     * @param position
     */
    setAudioFilePosition(position: number): number;
    /**
     * 调节音乐文件的本地播放音量
     * @param volume
     */
    adjustAudioFilePlayoutVolume(volume: number): number;
    /**
     * 调节音乐文件的远端播放音量
     * @param volume
     */
    adjustAudioFilePublishVolume(volume: number): number;
    /**
     * 获取音乐文件的本地播放音量
     */
    getAudioFilePlayoutVolume(): number;
    /**
     * 获取音乐文件的远端播放音量
     */
    getAudioFilePublishVolume(): number;
    /**
     * 获取音效文件的播放音量
     */
    getAudioClipsVolume(): number;
    /**
     * 设置音效文件的播放音量
     * @param volume
     */
    setAudioClipsVolume(volume: number): number;
    /**
     * 获取指定音效文件的播放音量
     * @param sounderId sounderId：指定音效Id
     */
    getVolumeOfAudioClip(sounderId: number): number;
    /**
     * 实时调整音效文件的播放音量
     * @param soundId
     * @param volume
     */
    setVolumeOfAudioClip(soundId: number, volume: number): number;
    /**
     * 播放指定音效文件
     * @param soundId 指定音效Id
     * @param filepath 文件路径
     * @param loop 循环播放次数
     * @param pitch 音效的音调，取值范围为 [0.5,2.0]。默认值为 1.0，表示原始音调。取值越小，则音调越低
     * @param pan 音效的空间位置。取值范围为 [-1.0,1.0]
     * @param gain 音效的音量
     * @param publish 是否推送
     * @param startPos 播放起始位置
     */
    playAudioClip(soundId: number, filepath: string, loop: number, pitch: number, pan: number, gain: number, publish: number, startPos: number): number;
    /**
     * 停止播放音乐文件，房间内调用
     * @param soundId
     */
    stopAudioClip(soundId: number): number;
    /**
     * 停止播放所有音效文件
     */
    stopAllAudioClips(): number;
    /**
     * 将音效文件加载至内存
     * @param soundId 指定音效Id
     * @param filePath 文件路径
     */
    preloadAudioClip(soundId: number, filePath: string): number;
    /**
     * 从内存释放某个预加载的音效文件。
     * @param soundId 指定音效Id
     */
    unloadAudioClip(soundId: number): number;
    /**
     * 暂停音效文件播放
     * @param soundId
     */
    pauseAudioClip(soundId: number): number;
    /**
     * 暂停所有音效文件播放
     */
    pauseAllAudioClips(): number;
    /**
     * 恢复播放指定音效文件
     * @param soundId
     */
    resumeAudioClip(soundId: number): number;
    /**
     * 恢复播放所有音效文件
     */
    resumeAllAudioClips(): number;
    /**
     * 获取指定音效文件的播放进度
     * @param soundId
     */
    getAudioClipCurrentPosition(soundId: number): number;
    /**
     * 设置指定音效文件的播放位置
     * @param soundId
     * @param position 播放进度
     */
    setAudioClipPosition(soundId: number, position: number): number;
    /**
     * 获取指定音效文件总时长
     * @param filePath
     */
    getAudioClipDuration(filePath: string): number;
    /**
     * 开始通话前网络质量探测
     * @param config
     */
    startNetworkTest(config: HRTCNetworkTestConfig): number;
    /**
     * 停止通话前网络质量探测
     */
    stopNetworkTest(): number;
    getDeviceId(): string;
    /**
     * 桌面共享
     */
    /**
     * 获取屏幕可共享对象列表
     * @param type type：屏幕捕获图像类型，0： 1：
     */
    getScreenCaptureSources(type: HRTCScreenCaptureIconType): HRTCScreenCaptureSourceInfos;
    /**
     * 选择屏幕共享对象
     * @param info
     * @param optionalInfo
     */
    selectScreenCaptureTarget(info: HRTCScreenCaptureSourceInfo, optionalInfo: HRTCSrceenCaptureOptionalInfo): number;
    startScreenCapture(): number;
    stopScreenCapture(): number;
    /**
     * 当远端开启屏幕共享，本地接收到远端屏幕共享开启onUserSubStreamAvailable消息后，设置屏幕共享流窗口视图（发起共享流选看）。
     * @param userId
     * @param view
     */
    startRemoteSubStreamView(userId: string): number;
    /**
     * 关闭屏幕共享流窗口视图（停止共享流选看）
     * @param userId
     */
    stopRemoteSubStreamView(userId: string): number;
    /**
     * 设置共享流视图渲染模式
     * @param userId
     * @param viewMode
     */
    setRemoteSubStreamViewDisplayMode(userId: string, viewMode: HRTCVideoDisplayMode): number;
    /**
     * 设置是否开启屏幕共享流的流畅度优先（降低共享流选看分辨率）
     * @param enable
     */
    setScreenSmooth(enable: boolean): number;
    /**
     * 设置是否开启远端共享流视图渲染的镜像模式
     * @param userId
     * @param enable
     */
    setRemoteSubStreamViewMirrorMode(userId: string, enable: boolean): number;
    /**
     *将指定窗口加入屏幕共享排除列表，屏幕共享时，在排除列表中的窗口将不会被共享出去。
     *支持屏幕共享前添加，也支持屏幕共享中动态添加。
     *注：windows7系统，通过DwmIsCompositionEnabled查询为关闭的场景下不可用。
     *windows10系统1607以前的版本，通过GetProcessDpiAwareness查询为PROCESS_DPI_UNAWARE或者PROCESS_SYSTEM_DPI_AWARE，则在系统dpi非100%场景不可用。建议应用以PROCESS_PER_MONITOR_DPI_AWARE模式使用
     * @param view 窗口ID（对象）
     */
    addExcludedShareWindow(view: number): number;
    /**
     * 将指定窗口从屏幕共享排除列表中移除。支持屏幕共享前移除，也支持屏幕共享中动态移除
     * @param view 窗口ID（对象）
     */
    removeExcludedShareWindow(view: number): number;
    /**
     * 将所有窗口从屏幕共享排除列表中移除。支持屏幕共享前移除，也支持屏幕共享中动态移除
     */
    removeAllExcludedShareWindow(): number;
    /**
     * 加载vad模型
     * @param modelPath 模型路径
     */
    loadVoiceActivityDetectionModel(modelPath: string): number;
    /**
     * 卸载vad模型
     */
    unloadVoiceActivityDetectionModel(): number;
    /**
     * 设置辅流编码参数
     * @param encoderParams
     */
    setSubStreamEncParam(encoderParams: HRTCSubStreamEncParam): number;
    /**
     * 设置视频编码分辨率比例模式
     * @param resolutionMode
     */
    setVideoEncodeResolutionMode(resolutionMode: HRTCVideoEncodeResolutionMode): number;
    /**
     * 设置是否开启共享流自渲染。开启后，回调onRenderDataFrame中会有共享流数据上报
     * @param localEnable
     * @param remoteEnable
     */
    setExternalDataFrameOutput(localEnable: boolean, remoteEnable: boolean): number;
}
export {};
