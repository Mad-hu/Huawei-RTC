import { IRenderer } from '../Renderer/index';
/**
 * 负责统计并打印sdk调用信息
 */
declare class StatisticalServices {
    private userInfoMap;
    private hRtcEngine;
    private apiSizeMap;
    constructor();
    setRtcEngine(hRtcEngine: any): void;
    printLog(msg: string): void;
    apiIncreateOnce(api: string): void;
    cbIncreateOnce(api: string): void;
    getUser(uid: string): UserInfo | undefined;
    private handleHearBeat;
    private getAPIInfo;
}
declare class UserInfo {
    private videoGlRender;
    private videoSoftRender;
    private videoRGBARender;
    private auxGlRender;
    private auxSoftRender;
    private auxRGBARender;
    private auxSize;
    private videoSize;
    private auxSuc;
    private videoSuc;
    private auxMiss;
    private videoMiss;
    tmpId: string;
    constructor(uid: string);
    getVideoInfo(): string;
    /**
     * 0 为视频流 1位辅流
     * @param streamType
     * @param renderers
     */
    setRendererLength(streamType: number, renderers: Array<IRenderer>): void;
    /**
     *
     * @param type 视频类型 1为辅流，其余为视频流
     */
    videoSizeIncrementOnce(type: number): this;
    videoSucIncrementOnce(type: number): this;
    videoMissIncrementOnce(type: number): this;
}
declare const statisticalServices: StatisticalServices;
export default statisticalServices;
