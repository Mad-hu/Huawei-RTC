/*
 * @Author: Yandong Hu
 * @github: https://github.com/Mad-hu
 * @Date: 2021-08-10 16:12:49
 * @LastEditTime: 2021-09-10 16:17:58
 * @LastEditors: Yandong Hu
 * @Description:
 */
let bjysdk;
if(process.platform == 'win32') {
  bjysdk = require('./platform/win32/sunloginsdk.node');
} else {
  bjysdk = require('./platform/mac/bjysdk.node');
}
module.exports = bjysdk;

