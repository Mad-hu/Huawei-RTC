/**
 * 当从npm 仓库安装时 触发该脚本，同步lib库
 */
const { task, option, argv } = require('just-task');
const fs = require('fs-extra');
const path = require('path');
const download = require('download');

option('platform', { default: process.platform, choices: ['darwin', 'win32', 'linux'] });
const packageObject = require('./package.json');
var child = require('child_process');

task('install', async () => {
  const platform = argv().platform;
  const version = packageObject.version;
  console.log(`just install start platform=${platform} version=${version}`, platform);

  // 下载文件
  let cacheDir = child.execSync('npm get cache', { encoding: 'utf8' });
  cacheDir = cacheDir.replace('\n', '');
  cacheDir = path.join(cacheDir, '_cacache', 'hrtc-lib', version);
  let sourcePath;
  if (platform === 'win32') {
    if (version.indexOf('mirror') !== -1) {
      sourcePath = path.join(cacheDir, 'lib_winTest', 'build', 'Release');
    } else if (version.indexOf('prod') !== -1) {
      sourcePath = path.join(cacheDir, 'lib_win', 'build', 'Release');
    }
  } else if (platform === 'darwin') {
    if (version.indexOf('mirror') !== -1) {
      sourcePath = path.join(cacheDir, 'lib_macTest', 'build', 'Release');
    } else if (version.indexOf('prod') !== -1) {
      sourcePath = path.join(cacheDir, 'lib_mac', 'build', 'Release');
    }
  }
  console.log(`sourcePath=${sourcePath}`);
  if (fs.existsSync(`${sourcePath}`)) {
    console.log('file exist');
  } else {
    let libName;
    if (platform === 'win32') {
      libName = 'hrtc-electron-lib-win';
    } else if (platform === 'darwin') {
      libName = 'hrtc-electron-lib-mac';
    }
    const fileName = `${libName}-${version}.tgz`;
    const downloadUrl = `http://cmc.centralrepo.rnd.huawei.com/artifactory/product_npm/@hw-wisecloudpanshi/${libName}/-/@hw-wisecloudpanshi/${fileName}`;
    console.log(`download start downloadUrl=${downloadUrl}`);
    await download(downloadUrl, cacheDir, { filename: fileName, extract: true });
    console.log(`download success`);
  }

  //将下载好的文件拷贝到
  const buildPath = path.join(__dirname, 'build', 'Release');

  console.log(`copy lib start platform=${platform} source=${sourcePath} dest=${buildPath}`);
  fs.copySync(sourcePath, buildPath);
});
